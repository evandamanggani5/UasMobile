package com.example.project_si

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.example.project_si.ui.theme.ProjectSITheme

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EnvironmentDataScreen(navController: NavController) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Environment Data", fontWeight = FontWeight.Bold, fontSize = 24.sp) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF800080))
            )
        },
        content = { paddingValues ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "Upload Progress Kamu",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    modifier = Modifier.padding(16.dp)
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Pilih Bidang Yang Ingin Di Upload",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    modifier = Modifier.padding(8.dp)
                )
                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = { /* Navigate to Sistem Cerdas upload screen */ },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00FFFF)),
                    modifier = Modifier.padding(8.dp)
                ) {
                    Text("Sistem Cerdas")
                }

                Button(
                    onClick = { /* Navigate to Data Processing upload screen */ },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00FF00)),
                    modifier = Modifier.padding(8.dp)
                ) {
                    Text("Data Processing")
                }

                Button(
                    onClick = { /* Navigate to Machine Learning upload screen */ },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFFA500)),
                    modifier = Modifier.padding(8.dp)
                ) {
                    Text("Machine Learning")
                }

                Button(
                    onClick = { /* Navigate to Neural Network upload screen */ },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF4500)),
                    modifier = Modifier.padding(8.dp)
                ) {
                    Text("Neural Network")
                }
            }
        }
    )
}

@Preview(showBackground = true)
@Composable
fun EnvironmentDataScreenPreview() {
    ProjectSITheme {
        EnvironmentDataScreen(navController = rememberNavController())
    }
}
