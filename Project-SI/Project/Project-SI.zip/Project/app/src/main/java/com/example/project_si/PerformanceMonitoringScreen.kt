package com.example.project_si

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.ArrowDropUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.example.project_si.ui.theme.ProjectSITheme

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PerformanceMonitoringScreen(navController: NavController) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedBidang by remember { mutableStateOf("Pilih Bidang") }
    var isBidangDropdownExpanded by remember { mutableStateOf(false) }
    var selectedPertemuan by remember { mutableStateOf("Pilih Pertemuan") }
    var isPertemuanDropdownExpanded by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Performance Monitoring", fontWeight = FontWeight.Bold, fontSize = 24.sp) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF800080))
            )
        },
        content = { paddingValues ->
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .padding(horizontal = 24.dp, vertical = 16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                item {
                    Text(
                        text = "Lihat Progress Project Anda Disini",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF800080),
                        modifier = Modifier.padding(vertical = 16.dp)
                    )
                }
                item {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        label = { Text("Tempel ID Project Disini") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 8.dp)
                    )
                }
                item {
                    Button(
                        onClick = { /* Logic untuk mencari project berdasarkan ID */ },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00B0FF)),
                        modifier = Modifier.padding(vertical = 8.dp)
                    ) {
                        Text("Search")
                    }
                }
                item {
                    Spacer(modifier = Modifier.height(24.dp))
                    Text(
                        text = "Doctor AI",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF800080),
                        modifier = Modifier.padding(vertical = 16.dp)
                    )
                }
                items(listOf("Sistem Cerdas", "Data Processing", "Machine Learning", "Neural Network")) { bidang ->
                    ProgressSection(bidang)
                }
                item {
                    Spacer(modifier = Modifier.height(24.dp))
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFFB3E5FC))
                            .padding(16.dp)
                    ) {
                        Text(
                            text = "Lihat Bukti Progressnya Disini",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF800080),
                            modifier = Modifier.padding(bottom = 8.dp)
                        )
                        Box {
                            OutlinedTextField(
                                value = selectedBidang,
                                onValueChange = { selectedBidang = it },
                                label = { Text("Pilih Bidang") },
                                readOnly = true,
                                trailingIcon = {
                                    Icon(
                                        imageVector = if (isBidangDropdownExpanded) Icons.Filled.ArrowDropUp else Icons.Filled.ArrowDropDown,
                                        contentDescription = null,
                                        modifier = Modifier.clickable { isBidangDropdownExpanded = !isBidangDropdownExpanded }
                                    )
                                },
                                modifier = Modifier.fillMaxWidth()
                            )
                            DropdownMenu(
                                expanded = isBidangDropdownExpanded,
                                onDismissRequest = { isBidangDropdownExpanded = false }
                            ) {
                                DropdownMenuItem(
                                    text = { Text("Sistem Cerdas") },
                                    onClick = {
                                        selectedBidang = "Sistem Cerdas"
                                        isBidangDropdownExpanded = false
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("Data Processing") },
                                    onClick = {
                                        selectedBidang = "Data Processing"
                                        isBidangDropdownExpanded = false
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("Machine Learning") },
                                    onClick = {
                                        selectedBidang = "Machine Learning"
                                        isBidangDropdownExpanded = false
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("Neural Network") },
                                    onClick = {
                                        selectedBidang = "Neural Network"
                                        isBidangDropdownExpanded = false
                                    }
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                        Box {
                            OutlinedTextField(
                                value = selectedPertemuan,
                                onValueChange = { selectedPertemuan = it },
                                label = { Text("Pilih Pertemuan") },
                                readOnly = true,
                                trailingIcon = {
                                    Icon(
                                        imageVector = if (isPertemuanDropdownExpanded) Icons.Filled.ArrowDropUp else Icons.Filled.ArrowDropDown,
                                        contentDescription = null,
                                        modifier = Modifier.clickable { isPertemuanDropdownExpanded = !isPertemuanDropdownExpanded }
                                    )
                                },
                                modifier = Modifier.fillMaxWidth()
                            )
                            DropdownMenu(
                                expanded = isPertemuanDropdownExpanded,
                                onDismissRequest = { isPertemuanDropdownExpanded = false }
                            ) {
                                DropdownMenuItem(
                                    text = { Text("Pertemuan 1") },
                                    onClick = {
                                        selectedPertemuan = "Pertemuan 1"
                                        isPertemuanDropdownExpanded = false
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("Pertemuan 2") },
                                    onClick = {
                                        selectedPertemuan = "Pertemuan 2"
                                        isPertemuanDropdownExpanded = false
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("Pertemuan 3") },
                                    onClick = {
                                        selectedPertemuan = "Pertemuan 3"
                                        isPertemuanDropdownExpanded = false
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("Pertemuan 4") },
                                    onClick = {
                                        selectedPertemuan = "Pertemuan 4"
                                        isPertemuanDropdownExpanded = false
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("Pertemuan 5") },
                                    onClick = {
                                        selectedPertemuan = "Pertemuan 5"
                                        isPertemuanDropdownExpanded = false
                                    }
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(
                            onClick = { /* Logic untuk submit */ },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFFC107))
                        ) {
                            Text("Submit")
                        }
                    }
                }
            }
        }
    )
}

@Composable
fun ProgressSection(title: String) {
    Column(modifier = Modifier.padding(vertical = 4.dp)) {
        Text(
            text = title,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF0000FF)
        )
        Spacer(modifier = Modifier.height(4.dp))
        Row {
            Text("Mulai", fontSize = 14.sp, color = Color.Black)
            Spacer(modifier = Modifier.width(8.dp))
            repeat(7) { index ->
                Box(
                    modifier = Modifier
                        .size(24.dp)
                        .background(if (index < 3) Color.Blue else Color.Gray)
                        .padding(4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = (index + 1).toString(),
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.width(4.dp))
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun PerformanceMonitoringScreenPreview() {
    ProjectSITheme {
        PerformanceMonitoringScreen(navController = rememberNavController())
    }
}
