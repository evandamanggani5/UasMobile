package com.example.project_si

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.ArrowDropUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.example.project_si.ui.theme.ProjectSITheme

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EnvironmentDataScreen2(navController: NavController) {
    var selectedMeeting by remember { mutableStateOf("Pilih Pertemuan") }
    var isDropdownExpanded by remember { mutableStateOf(false) }
    var progressDescription by remember { mutableStateOf("") }
    var filePath by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Upload Progress Kamu", fontWeight = FontWeight.Bold, fontSize = 24.sp) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF800080))
            )
        },
        content = { paddingValues ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .padding(16.dp)
                    .background(Color(0xFF800080)),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "Sistem Cerdas",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(16.dp),
                    color = Color.White
                )
                Spacer(modifier = Modifier.height(16.dp))

                Box {
                    OutlinedTextField(
                        value = selectedMeeting,
                        onValueChange = { },
                        label = { Text("Pilih Pertemuan Progress") },
                        readOnly = true,
                        trailingIcon = {
                            Icon(
                                imageVector = if (isDropdownExpanded) Icons.Filled.ArrowDropUp else Icons.Filled.ArrowDropDown,
                                contentDescription = null,
                                modifier = Modifier.clickable { isDropdownExpanded = !isDropdownExpanded }
                            )
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color.White)
                    )
                    DropdownMenu(
                        expanded = isDropdownExpanded,
                        onDismissRequest = { isDropdownExpanded = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("Pertemuan 1") },
                            onClick = {
                                selectedMeeting = "Pertemuan 1"
                                isDropdownExpanded = false
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Pertemuan 2") },
                            onClick = {
                                selectedMeeting = "Pertemuan 2"
                                isDropdownExpanded = false
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Pertemuan 3") },
                            onClick = {
                                selectedMeeting = "Pertemuan 3"
                                isDropdownExpanded = false
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Pertemuan 4") },
                            onClick = {
                                selectedMeeting = "Pertemuan 4"
                                isDropdownExpanded = false
                            }
                        )
                        // Tambahkan lebih banyak pertemuan jika diperlukan
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                BasicTextField(
                    value = progressDescription,
                    onValueChange = { progressDescription = it },
                    keyboardOptions = KeyboardOptions.Default.copy(
                        keyboardType = KeyboardType.Text,
                        imeAction = ImeAction.Done
                    ),
                    keyboardActions = KeyboardActions(
                        onDone = {
                            // Handle onDone action
                        }
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(100.dp)
                        .padding(16.dp)
                        .background(Color.LightGray)
                        .padding(8.dp)
                )

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = {
                        // Logic untuk menambahkan bukti
                        filePath = "path/to/your/file" // Simulasi path file yang dipilih
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00B0FF)),
                    modifier = Modifier.padding(8.dp)
                ) {
                    Text("Tambah Bukti")
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(text = filePath, color = Color.Gray)

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = {
                        // Logic untuk submit
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFFC107)),
                    modifier = Modifier.padding(8.dp)
                ) {
                    Text("Submit")
                }
            }
        }
    )
}

@Preview(showBackground = true)
@Composable
fun EnvironmentDataScreen2Preview() {
    ProjectSITheme {
        EnvironmentDataScreen2(navController = rememberNavController())
    }
}
