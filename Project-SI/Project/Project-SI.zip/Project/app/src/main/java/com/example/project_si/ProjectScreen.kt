package com.example.project_si

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.ClipboardManager
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.example.project_si.ui.theme.ProjectSITheme

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProjectScreen(navController: NavController) {
    val snackbarHostState = remember { SnackbarHostState() }

    Scaffold(
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        topBar = {
            TopAppBar(
                title = { Text("Project", fontWeight = FontWeight.Bold, fontSize = 24.sp) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF800080))
            )
        },
        content = { paddingValues ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "Cari Project Yang Anda Cari Disini",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(16.dp),
                    color = Color(0xFF0000FF)
                )
                Spacer(modifier = Modifier.height(16.dp))
                SearchProjectBar()
                Spacer(modifier = Modifier.height(16.dp))
                ProjectTable(snackbarHostState)
                Spacer(modifier = Modifier.height(16.dp))
                Button(
                    onClick = {
                        // Navigation to the next screen or any other action
                        navController.navigate("next_screen_route")
                    },
                    modifier = Modifier.padding(8.dp)
                ) {
                    Text("Next")
                }
            }
        }
    )
}

@Composable
fun SearchProjectBar() {
    var searchQuery by remember { mutableStateOf("") }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            label = { Text("Nama Project") },
            modifier = Modifier
                .weight(1f)
                .padding(end = 8.dp)
        )
        Button(onClick = { /* Logic untuk mencari project */ }) {
            Text("Cari")
        }
    }
}

@Composable
fun ProjectTable(snackbarHostState: SnackbarHostState) {
    val clipboardManager: ClipboardManager = LocalClipboardManager.current
    val context = LocalContext.current

    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.Gray)
                .padding(8.dp)
        ) {
            Text("Nama Project", modifier = Modifier.weight(1f).padding(4.dp))
            Text("Anggota", modifier = Modifier.weight(1f).padding(4.dp))
            Text("Tanggal Pembuatan", modifier = Modifier.weight(1f).padding(4.dp))
            Text("Deskripsi", modifier = Modifier.weight(1f).padding(4.dp))
            Text("Aksi", modifier = Modifier.weight(1f).padding(4.dp))
        }
        Spacer(modifier = Modifier.height(4.dp))
        ProjectRow(
            name = "Futsal AI",
            members = "Hafidz, Manca, Adit, Usop",
            date = "25 Juni 2024",
            description = "Sebuah Aplikasi Untuk Melakukan...",
            clipboardManager = clipboardManager,
            snackbarHostState = snackbarHostState,
            context = context
        )
    }
}

@Composable
fun ProjectRow(
    name: String,
    members: String,
    date: String,
    description: String,
    clipboardManager: ClipboardManager,
    snackbarHostState: SnackbarHostState,
    context: Context
) {
    var showSnackbar by remember { mutableStateOf(false) }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp)
    ) {
        Text(name, modifier = Modifier.weight(1f).padding(4.dp))
        Text(members, modifier = Modifier.weight(1f).padding(4.dp))
        Text(date, modifier = Modifier.weight(1f).padding(4.dp))
        Text(description, modifier = Modifier.weight(1f).padding(4.dp))
        Button(
            onClick = {
                clipboardManager.setText(androidx.compose.ui.text.AnnotatedString(name))
                showSnackbar = true
            },
            modifier = Modifier.padding(4.dp)
        ) {
            Text("Salin ID")
        }
    }

    if (showSnackbar) {
        LaunchedEffect(Unit) {
            snackbarHostState.showSnackbar("ID Project Berhasil Disalin")
            showSnackbar = false
        }
    }
}

@Preview(showBackground = true)
@Composable
fun ProjectScreenPreview() {
    ProjectSITheme {
        ProjectScreen(navController = rememberNavController())
    }
}
