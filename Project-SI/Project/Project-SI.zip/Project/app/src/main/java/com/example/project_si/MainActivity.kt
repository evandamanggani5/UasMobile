package com.example.project_si

import androidx.compose.runtime.Composable
import androidx.compose.ui.tooling.preview.Preview
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.project_si.ui.theme.ProjectSITheme

@Preview(showBackground = true)
@Composable
fun DefaultPreview() {
    val userViewModel = UserViewModel()
    ProjectSITheme {
        val navController = rememberNavController()
        NavHost(navController, startDestination = "login") {
            composable("login") { LoginScreen(navController, userViewModel) }
            composable("register") { RegisterScreen(navController, userViewModel) }
            composable("home") { HomeScreen(navController) }
            composable("project") { ProjectScreen(navController) }
            composable("add_project") { AddProjectScreen(navController) }
            composable("transaction_data") { TransactionDataScreen(navController) }
            composable("environment_data") { EnvironmentDataScreen(navController) }
            composable("environment_data2") { EnvironmentDataScreen2(navController) }
            composable("environment_data3") { EnvironmentDataScreen3(navController) }
            composable("environment_data4") { EnvironmentDataScreen4(navController) }
            composable("performance_monitoring") { PerformanceMonitoringScreen(navController) }
        }
    }
}
