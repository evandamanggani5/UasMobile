package com.example.project_si

import androidx.lifecycle.ViewModel

class UserViewModel : ViewModel() {
    private val users = mutableMapOf<String, String>()

    fun registerUser(username: String, password: String): Boolean {
        return if (users.containsKey(username)) {
            false
        } else {
            users[username] = password
            true
        }
    }

    fun loginUser(username: String, password: String): Boolean {
        return users[username] == password
    }
}
