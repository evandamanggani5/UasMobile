package com.example.project_si

import android.content.Context
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.example.project_si.ui.theme.ProjectSITheme


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddProjectScreen(navController: NavController) {
    val context = LocalContext.current
    val sharedPreferences = context.getSharedPreferences("project_prefs", Context.MODE_PRIVATE)

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Project", fontWeight = FontWeight.Bold, fontSize = 24.sp) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF800080))
            )
        },
        content = { paddingValues ->
            Column(
                modifier = Modifier
                    .padding(paddingValues)
                    .padding(16.dp)
            ) {
                DisplaySavedData()
            }
        }
    )
}

@Composable
fun DisplaySavedData() {
    val context = LocalContext.current
    val sharedPreferences = context.getSharedPreferences("project_prefs", Context.MODE_PRIVATE)

    val projectName = sharedPreferences.getString("project_name", "Default Name") ?: "Default Name"
    val projectDescription = sharedPreferences.getString("project_description", "Default Description") ?: "Default Description"
    val projectMembers = sharedPreferences.getString("project_members", "Default Members") ?: "Default Members"
    val projectDate = sharedPreferences.getString("project_date", "Default Date") ?: "Default Date"

    Column(modifier = Modifier.padding(16.dp)) {
        Text(text = "Nama Project: $projectName")
        Text(text = "Deskripsi: $projectDescription")
        Text(text = "Anggota: $projectMembers")
        Text(text = "Tanggal: $projectDate")
    }
}

@Preview(showBackground = true)
@Composable
fun AddProjectScreenPreview() {
    ProjectSITheme {
        AddProjectScreen(navController = rememberNavController())
    }
}
