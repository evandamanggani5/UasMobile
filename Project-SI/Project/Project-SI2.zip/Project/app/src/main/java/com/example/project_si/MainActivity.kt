package com.example.project_si

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.Composable
import androidx.compose.ui.tooling.preview.Preview
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.project_si.ui.theme.ProjectSITheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ProjectSITheme {
                AppNavigator()
            }
        }
    }
}

@Composable
fun AppNavigator() {
    val navController = rememberNavController()
    NavHost(navController = navController, startDestination = "HomeScreen") {
        composable("Home_Screen") { HomeScreen(navController) }
        composable("project_screen") { ProjectScreen(navController) }
        // Tambahkan layar lain sesuai kebutuhan
    }
}

@Preview(showBackground = true)
@Composable
fun DefaultPreview() {
    ProjectSITheme {
        AppNavigator()
    }
}
