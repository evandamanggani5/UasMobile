package com.example.project_si

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.example.project_si.ui.theme.ProjectSITheme

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProjectScreen(navController: NavController) {
    val snackbarHostState = remember { SnackbarHostState() }

    Scaffold(
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        topBar = {
            TopAppBar(
                title = { Text("Project", fontWeight = FontWeight.Bold, fontSize = 24.sp) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF800080))
            )
        },
        content = { paddingValues ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "Cari Project Sistem Cerdas Yang Ingin Anda Ketahui",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(16.dp),
                    color = Color(0xFF0000FF)
                )
                Spacer(modifier = Modifier.height(16.dp))
                SearchProjectBar()
                Spacer(modifier = Modifier.height(16.dp))
                ProjectTable(snackbarHostState)
            }
        }
    )
}

@Composable
fun SearchProjectBar() {
    var searchQuery by remember { mutableStateOf("") }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            label = { Text("Nama Sistem Cerdas") },
            modifier = Modifier
                .weight(1f)
                .padding(end = 8.dp)
        )
        Button(onClick = { /* Logic untuk mencari project */ }) {
            Text("Cari")
        }
    }
}

@Composable
fun ProjectTable(snackbarHostState: SnackbarHostState) {
    val context = LocalContext.current

    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.Gray)
                .padding(8.dp)
        ) {
            Text("Nama Sistem Cerdas", modifier = Modifier.weight(1f).padding(4.dp))
            Text("Format File Models", modifier = Modifier.weight(1f).padding(4.dp))
            Text("Actions", modifier = Modifier.weight(1f).padding(4.dp))
        }
        Spacer(modifier = Modifier.height(4.dp))
        ProjectRow(
            name = "aX",
            format = "Format1",
            context = context,
            snackbarHostState = snackbarHostState
        )
        ProjectRow(
            name = "Ba",
            format = "Format2",
            context = context,
            snackbarHostState = snackbarHostState
        )
        ProjectRow(
            name = "5a",
            format = "Format3",
            context = context,
            snackbarHostState = snackbarHostState
        )
    }
}

@Composable
fun ProjectRow(
    name: String,
    format: String,
    context: Context,
    snackbarHostState: SnackbarHostState
) {
    var showSnackbar by remember { mutableStateOf(false) }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp)
    ) {
        Text(name, modifier = Modifier.weight(1f).padding(4.dp))
        Text(format, modifier = Modifier.weight(1f).padding(4.dp))
        Button(
            onClick = {
                // Simulate downloading the project
                showSnackbar = true
            },
            modifier = Modifier.padding(4.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color.Green)
        ) {
            Text("Download", color = Color.White)
        }
    }

    if (showSnackbar) {
        LaunchedEffect(Unit) {
            snackbarHostState.showSnackbar("Project Berhasil Diunduh")
            showSnackbar = false
        }
    }
}

@Preview(showBackground = true)
@Composable
fun ProjectScreenPreview() {
    ProjectSITheme {
        ProjectScreen(navController = rememberNavController())
    }
}
